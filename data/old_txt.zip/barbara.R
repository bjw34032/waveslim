barbara <- matrix(scan("barbara.txt", quiet=TRUE), 256, 256)

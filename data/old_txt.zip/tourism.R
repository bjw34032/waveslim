tourism <- ts(scan("tourism.txt", quiet=TRUE), start=1960, freq=4)

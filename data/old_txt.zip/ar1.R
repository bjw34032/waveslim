ar1 <- scan("ar1.txt", quiet=TRUE)

unemploy <- ts(read.table("unemploy.txt")$V3, start=1948, freq=12)

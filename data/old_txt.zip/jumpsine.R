jumpsine <- ts(scan("jumpsine.txt", quiet=TRUE))

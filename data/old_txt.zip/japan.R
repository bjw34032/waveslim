japan <- ts(scan("japan.txt", quiet=TRUE), start=1955, freq=4)

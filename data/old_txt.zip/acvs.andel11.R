acvs.andel11 <- read.table("acvs.andel11.txt",
                           col.names=c("lag", "acvs", "acf"))

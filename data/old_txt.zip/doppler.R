doppler <- ts(scan("doppler.txt", quiet=TRUE))

dau <- matrix(scan("dau.txt", quiet=TRUE), 256, 256)

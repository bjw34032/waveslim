blocks <- ts(scan("blocks.txt", quiet=TRUE))

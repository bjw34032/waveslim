cpi <- ts(read.table("cpi.txt")$V3, start=1948, freq=12)

linchirp <- ts(scan("linchirp.txt", quiet=TRUE))

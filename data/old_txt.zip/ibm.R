ibm <- ts(scan("ibm.txt", quiet=TRUE))

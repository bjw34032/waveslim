mexm <- ts(scan("mexm.txt", quiet=TRUE), start=1957, freq=12)

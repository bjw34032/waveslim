acvs.andel9 <- read.table("acvs.andel9.txt", col.names=c("lag", "acvs", "acf"))

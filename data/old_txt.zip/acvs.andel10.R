acvs.andel10 <- read.table("acvs.andel10.txt",
                           col.names=c("lag", "acvs", "acf"))

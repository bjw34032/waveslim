saver = function(..., file) {
  save(...,
       file = paste0(file, ".rda"),
       compress = TRUE,
       compression_level = 9)
}
acvs.andel10 <- read.table("acvs.andel10.txt",
                           col.names=c("lag", "acvs", "acf"))
saver(acvs.andel10, file = "acvs.andel10")

acvs.andel11 <- read.table("acvs.andel11.txt",
                           col.names=c("lag", "acvs", "acf"))
saver(acvs.andel11, file = "acvs.andel11")

acvs.andel8 <- read.table("acvs.andel8.txt", col.names=c("lag", "acvs", "acf"))
saver(acvs.andel8, file = "acvs.andel8")

acvs.andel9 <- read.table("acvs.andel9.txt", col.names=c("lag", "acvs", "acf"))
saver(acvs.andel9, file = "acvs.andel9")

ar1 <- scan("ar1.txt", quiet=TRUE)
saver(ar1, file = "ar1")

barbara <- matrix(scan("barbara.txt", quiet=TRUE), 256, 256)
saver(barbara, file = "barbara")

blocks <- ts(scan("blocks.txt", quiet=TRUE))
saver(blocks, file = "blocks")

cpi <- ts(read.table("cpi.txt")$V3, start=1948, freq=12)
saver(cpi, file = "cpi")

dau <- matrix(scan("dau.txt", quiet=TRUE), 256, 256)
saver(dau, file = "dau")

doppler <- ts(scan("doppler.txt", quiet=TRUE))
saver(doppler, file = "doppler")

exchange <-
  ts(as.matrix(read.table("exchange.txt", col.names=c("DEM.USD", "JPY.USD"))),
     start=1970, freq=12)
saver(exchange, file = "exchange")

heavisine <- ts(scan("heavisine.txt", quiet=TRUE))
saver(heavisine, file = "heavisine")

ibm <- ts(scan("ibm.txt", quiet=TRUE))
saver(ibm, file = "ibm")

japan <- ts(scan("japan.txt", quiet=TRUE), start=1955, freq=4)
saver(japan, file = "japan")

jumpsine <- ts(scan("jumpsine.txt", quiet=TRUE))
saver(jumpsine, file = "jumpsine")

kobe <- ts(scan("kobe.txt", quiet=TRUE))
saver(kobe, file = "kobe")

linchirp <- ts(scan("linchirp.txt", quiet=TRUE))
saver(linchirp, file = "linchirp")

mexm <- ts(scan("mexm.txt", quiet=TRUE), start=1957, freq=12)
saver(mexm, file = "mexm")

##
##  Nile river minima
##

##  Yearly minimal water levels of the Nile river for the years 622
##  to 1281, measured at the Roda gauge near Cairo (Tousson, 1925,
##  p. 366-385). The data are listed in chronological sequence by row.

##  The original Nile river data supplied by Beran only contained only
##  500 observations (622 to 1121).  However, the book claimed to have
##  660 observations (622 to 1281).  I added the remaining observations
##  from the book, by hand, and still came up short with only 653
##  observations (622 to 1264).

### --- now have 663 observations : years  622--1284  (as in orig. source)

nile <- ts(c(1157,1088,1169,1169,984,1322,1178,1103,1211,1292,1124,
             1171,1133,1227,1142,1216,1259,1299,1232,1117,1155,
             1232,1083,1020,1394,1196,1148,1083,1189,1133,1034,
             1157,1034,1097,1299,1157,1130,1155,1349,1232,1103,
             1103,1083,1027,1166,1148,1250,1155,1047,1054,1018,
             1189,1126,1250,1297,1178,1043,1103,1250,1272,1169,
             1004,1083,1164,1124,1027,995,1169,1270,1011,1247,
             1101,1004,1004,1065,1223,1184,1216,1180,1142,1277,
             1206,1076,1076,1189,1121,1178,1031,1076,1178,1209,
             1022,1220,1070,1126,1058,1216,1358,1184,1083,1097,
             1119,1097,1097,1153,1153,1151,1151,1151,1184,1097,
             1043,1043,1002,1152,1097,1034,1002,989,1092,1115,
             1115,1047,1040,1038,1085,1126,1058,1067,1115,1263,
             1124,1110,1097,1097,1157,1000,991,995,1013,1007,
             971,971,980,993,1043,1097,982,971,971,1065,
             1022,1029,989,1029,995,982,1090,980,971,957,
             989,966,989,1022,1074,1110,1110,1061,1151,1128,
             1074,1043,1034,1074,966,1027,1029,1034,1065,989,
             1034,1002,1128,1178,1097,1142,1466,1097,1137,1097,
             1259,1313,1173,1169,1173,1088,1191,1146,1160,1142,
             1128,1169,1162,1115,1164,1088,1079,1083,1043,1110,
             1092,1110,1047,1076,1110,1043,1103,1034,1074,1052,
             1011,1097,1092,1110,1115,1097,1196,1115,1162,1151,
             1142,1126,1108,1187,1191,1153,1254,1187,1196,1331,
             1412,1349,1290,1211,1232,1166,1124,1146,1079,1108,
             1097,1106,1072,1065,1128,1340,959,959,1137,1133,
             1137,1151,1117,1157,1157,1133,1110,1155,1189,1260,
             1189,1151,1097,1209,1130,1295,1308,1250,1205,1310,
             1250,1155,1101,1100,1103,1121,1121,1097,1106,1259,
             1261,1124,1196,1205,1205,1119,1088,1250,1094,1198,
             1121,1164,1211,1153,1146,1126,1288,1175,1171,1081,
             1133,1164,1155,1155,1155,1160,1094,1054,1067,1044,
             948,1099,1016,1065,1067,1072,1076,1081,1196,1196,
             1151,1088,1128,1151,1236,1216,1288,1297,1182,1306,
             1043,1184,1054,1169,1043,980,1072,1189,1151,1142,
             1193,1151,1097,1144,1097,1094,1153,1108,935,1081,
             1081,1097,1146,1250,1151,1043,1043,1043,1070,1124,
             1137,1146,1099,1054,1045,1070,1142,1074,1101,1220,
             1196,1097,1207,1119,1160,1151,1025,1097,1137,1007,
             1034,1043,1043,980,1079,1169,1250,1324,1209,1142,
             1061,1000,1088,1128,1142,1259,1142,1148,1088,1142,
             1119,1130,1088,1250,1137,1108,1110,1173,1173,1196,
             1189,1200,1351,1274,1227,1310,1148,1151,1151,1182,
             1182,1151,1133,1130,1151,1166,1070,1200,1074,1110,
             1292,1178,1128,1097,1304,1103,1259,1119,1119,1119,
             1081,1196,1085,1101,1103,1146,1211,1169,1144,1191,
             1189,1182,1243,1243,1227,1189,1191,1155,1209,1218,
             1211,1209,1164,1135,1121,1137,1254,1457,1299,1277,
             1277,1178,1270,1313,1333,1270,1245,1245,1211,1265,
             1346,1346,1290,1295,1286,1259,1254,1421,1268,1263,
             1335,1313,1265,1319,1351,1277,1317,1268,1263,
             1112,1207,1292,1205,1223,1205,1153,1182,1245,1205,
             1151,1079,1151,1081,1128,1209,1157,1277,1259,1209,
             1220,1184,1220,1193,1247,1252,1259,1299,1173,1182,
             1180,1180,1331,1207,1236,1151,1182,1142,1191,1259,
             1166,1196,1241,1252,1241,1252,1157,1126,1164,1088,
             1173,1252,1288,1301,1286,1223,1232,1184,1207,1250,
             1256,1211,1216,1209,1209,1207,1151,1097,1097,989,
             966,1047,1056,1110,1290,1151,1166,1196,1196,1110,
             1110,1119,1119,1074,1106,1128,1218,1098,1044,1056,
             1058,1098,1043,1038,1142,1142,1193,1103,989,936,
             1142,1142,1151,1151,1180,1259,1196,1142,1169,1196,
             1142,1128,1043,1097,1142,1205,1205,1164,1160,1196,
             1112,1169,1110,1178,1133,1153,1139,1155,1187,1196,
             1220,1166,1128,1101,1157,1175,1142,1187,1254,1198,
             1263,1283,1252,1160,1234,1234,1232,1306,1205,1054,
             1151,1108,1097), 622, frequency=1)
saver(nile, file = "nile")


tourism <- ts(scan("tourism.txt", quiet=TRUE), start=1960, freq=4)
saver(tourism, file = "tourism")

unemploy <- ts(read.table("unemploy.txt")$V3, start=1948, freq=12)
saver(unemploy, file = "unemploy")

xbox <- matrix(scan("xbox.txt", quiet=TRUE), 128, 128)
saver(xbox, file = "xbox")

kobe <- ts(scan("kobe.txt", quiet=TRUE))

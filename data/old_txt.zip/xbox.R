xbox <- matrix(scan("xbox.txt", quiet=TRUE), 128, 128)

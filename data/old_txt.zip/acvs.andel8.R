acvs.andel8 <- read.table("acvs.andel8.txt", col.names=c("lag", "acvs", "acf"))

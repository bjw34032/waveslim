heavisine <- ts(scan("heavisine.txt", quiet=TRUE))
